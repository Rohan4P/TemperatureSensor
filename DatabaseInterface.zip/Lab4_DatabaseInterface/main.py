#  Author      : Rohan
#  ID          : 8696839
#  Description : Reading from serial port and upload it to database

import serial
import requests

#initializing serial port
ser = serial.Serial()
ser.baudrate = 115200
ser.port = 'COM3'
ser.timeout = 1
ser.close()
ser.open()

while 1:
    while (ser.inWaiting() > 0) : #to get the amount of bytes available at the input queue
        try:
            data = ser.readline().rstrip()
            newData = data.decode('utf8').split(';')
            r = requests.put(' http://esdserver:3000/api/ae35400be2f76505c71d7324412869c3/data', json=newData)
            rout = requests.get(' http://esdserver:3000/api/ae35400be2f76505c71d7324412869c3/data')
            print(rout.json())
        except serial.SerialException:
            print("No Data")